import React, { useEffect, useState } from 'react';
import { supabase } from './lib/supabase';
import { AuthForm } from './components/AuthForm';
import { FriendsList } from './components/FriendsList';
import { ChatWindow } from './components/ChatWindow';
import { User } from './types';
import { Toaster } from 'react-hot-toast';

function App() {
  const [session, setSession] = useState(null);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [selectedFriend, setSelectedFriend] = useState<User | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (session?.user) {
        setCurrentUser({
          id: session.user.id,
          email: session.user.email!,
          full_name: session.user.user_metadata.full_name,
          username: session.user.user_metadata.username
        });
      }
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (session?.user) {
        setCurrentUser({
          id: session.user.id,
          email: session.user.email!,
          full_name: session.user.user_metadata.full_name,
          username: session.user.user_metadata.username
        });
      } else {
        setCurrentUser(null);
        setSelectedFriend(null);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  if (!session) {
    return (
      <>
        <Toaster position="top-right" />
        <AuthForm type="login" />
      </>
    );
  }

  return (
    <>
      <Toaster position="top-right" />
      <div className="flex h-screen">
        {currentUser && (
          <FriendsList
            currentUser={currentUser}
            onSelectFriend={setSelectedFriend}
          />
        )}
        {selectedFriend && currentUser ? (
          <ChatWindow
            currentUser={currentUser}
            selectedFriend={selectedFriend}
          />
        ) : (
          <div className="flex-1 flex items-center justify-center bg-gray-50">
            <p className="text-gray-500">Select a friend to start chatting</p>
          </div>
        )}
      </div>
    </>
  );
}