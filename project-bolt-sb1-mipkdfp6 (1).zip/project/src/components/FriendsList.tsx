import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { User, FriendRequest } from '../types';
import toast from 'react-hot-toast';

interface FriendsListProps {
  currentUser: User;
  onSelectFriend: (friend: User) => void;
}

export function FriendsList({ currentUser, onSelectFriend }: FriendsListProps) {
  const [friends, setFriends] = useState<User[]>([]);
  const [pendingRequests, setPendingRequests] = useState<FriendRequest[]>([]);
  const [searchUsername, setSearchUsername] = useState('');

  useEffect(() => {
    loadFriends();
    loadPendingRequests();
    subscribeToFriendRequests();
  }, []);

  const loadFriends = async () => {
    const { data, error } = await supabase
      .from('friend_requests')
      .select(`
        *,
        sender:sender_id(id, email, full_name, username),
        receiver:receiver_id(id, email, full_name, username)
      `)
      .or(`sender_id.eq.${currentUser.id},receiver_id.eq.${currentUser.id}`)
      .eq('status', 'accepted');

    if (error) {
      toast.error('Error loading friends');
      return;
    }

    const friendsList = data.map(request => {
      return request.sender_id === currentUser.id ? request.receiver : request.sender;
    });

    setFriends(friendsList);
  };

  const loadPendingRequests = async () => {
    const { data, error } = await supabase
      .from('friend_requests')
      .select(`
        *,
        sender:sender_id(id, email, full_name, username)
      `)
      .eq('receiver_id', currentUser.id)
      .eq('status', 'pending');

    if (error) {
      toast.error('Error loading requests');
      return;
    }

    setPendingRequests(data);
  };

  const subscribeToFriendRequests = () => {
    supabase
      .channel('friend_requests')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'friend_requests' },
        payload => {
          if (payload.new.receiver_id === currentUser.id) {
            loadPendingRequests();
          }
          if (payload.new.status === 'accepted') {
            loadFriends();
          }
        }
      )
      .subscribe();
  };

  const sendFriendRequest = async () => {
    if (!searchUsername.trim()) {
      toast.error('Please enter a username');
      return;
    }

    const { data: users, error: searchError } = await supabase
      .from('users')
      .select('*')
      .eq('username', searchUsername.toLowerCase())
      .single();

    if (searchError || !users) {
      toast.error('User not found');
      return;
    }

    if (users.id === currentUser.id) {
      toast.error('You cannot add yourself as a friend');
      return;
    }

    const { error } = await supabase
      .from('friend_requests')
      .insert({
        sender_id: currentUser.id,
        receiver_id: users.id,
        status: 'pending'
      });

    if (error) {
      if (error.code === '23505') {
        toast.error('Friend request already sent');
      } else {
        toast.error('Error sending friend request');
      }
      return;
    }

    toast.success('Friend request sent!');
    setSearchUsername('');
  };

  const handleRequest = async (requestId: string, status: 'accepted' | 'rejected') => {
    const { error } = await supabase
      .from('friend_requests')
      .update({ status })
      .eq('id', requestId);

    if (error) {
      toast.error(`Error ${status === 'accepted' ? 'accepting' : 'rejecting'} request`);
      return;
    }

    toast.success(`Request ${status === 'accepted' ? 'accepted' : 'rejected'}`);
    loadPendingRequests();
    if (status === 'accepted') {
      loadFriends();
    }
  };

  return (
    <div className="w-64 bg-gray-50 p-4 border-r">
      <div className="mb-4">
        <input
          type="text"
          placeholder="Search by username"
          value={searchUsername}
          onChange={(e) => setSearchUsername(e.target.value)}
          className="w-full p-2 border rounded"
        />
        <button
          onClick={sendFriendRequest}
          className="w-full mt-2 bg-indigo-600 text-white p-2 rounded hover:bg-indigo-700"
        >
          Send Request
        </button>
      </div>

      {pendingRequests.length > 0 && (
        <div className="mb-4">
          <h3 className="font-bold mb-2">Pending Requests</h3>
          {pendingRequests.map((request) => (
            <div key={request.id} className="mb-2 p-2 bg-white rounded shadow">
              <p className="text-sm mb-2">From: {request.sender.full_name}</p>
              <p className="text-xs text-gray-500 mb-2">@{request.sender.username}</p>
              <div className="flex space-x-2">
                <button
                  onClick={() => handleRequest(request.id, 'accepted')}
                  className="bg-green-500 text-white px-2 py-1 rounded text-sm"
                >
                  Accept
                </button>
                <button
                  onClick={() => handleRequest(request.id, 'rejected')}
                  className="bg-red-500 text-white px-2 py-1 rounded text-sm"
                >
                  Reject
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <div>
        <h3 className="font-bold mb-2">Friends</h3>
        {friends.map((friend) => (
          <div
            key={friend.id}
            onClick={() => onSelectFriend(friend)}
            className="p-2 hover:bg-gray-100 cursor-pointer rounded"
          >
            <p>{friend.full_name}</p>
            <p className="text-xs text-gray-500">@{friend.username}</p>
          </div>
        ))}
      </div>
    </div>
  );
}